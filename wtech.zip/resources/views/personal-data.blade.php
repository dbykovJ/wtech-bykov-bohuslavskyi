@extends('layouts.app')

@section('title', 'Your Data — SUPERSELL')

@push('styles')
    <link rel="stylesheet" href="{{ asset('css/card.css') }}"/>
    <link rel="stylesheet" href="{{ asset('css/personal-data.css') }}"/>
@endpush

@section('content')
    <main class="personal-main">
        <div class="container">
            <div class="breadcrumb">
                <a href="{{ route('cart') }}">Cart</a>
                <span class="breadcrumb__sep">›</span>
                <span class="breadcrumb__current">Personal data</span>
            </div>

            <h1 class="personal-title heading">YOUR DATA</h1>

            <div class="personal-layout">
                <div class="personal-left">
                    <form class="personal-form" method="POST" action="{{ route('checkout.personal-data.store') }}">

                        <div class="option-card option-card--section">
                            <h2 class="option-card__title">Delivery Method</h2>

                            <label class="option-single-choice">
                                <div class="option-single-choice__left">
                                    <div class="placeholder option-single-choice__logo"></div>
                                    <span class="option-single-choice__name">Truck</span>
                                </div>
                                <input type="radio" name="delivery_method" value="truck" class="option-single-choice__radio"
                                       checked/>
                                <span class="option-single-choice__custom-radio"></span>
                            </label>

                            <label class="option-single-choice">
                                <div class="option-single-choice__left">
                                    <div class="placeholder option-single-choice__logo"></div>
                                    <span class="option-single-choice__name">Post courier</span>
                                </div>
                                <input type="radio" name="delivery_method" value="post" class="option-single-choice__radio"/>
                                <span class="option-single-choice__custom-radio"></span>
                            </label>

                            <label class="option-single-choice">
                                <div class="option-single-choice__left">
                                    <div class="placeholder option-single-choice__logo"></div>
                                    <span class="option-single-choice__name">Drop box near you</span>
                                </div>
                                <input type="radio" name="delivery_method" value="drop box"
                                       class="option-single-choice__radio"/>
                                <span class="option-single-choice__custom-radio"></span>
                            </label>

                            @error('delivery_method')<span class="field-error">{{ $message }}</span>@enderror
                        </div>

                        <div class="personal-form-box">
                            @csrf
                            <input type="text" name="full_name" class="personal-input" placeholder="Full Name"
                                   value="{{ old('full_name', $address['full_name'] ?? $lastOrder?->shipping_full_name ?? auth()->user()?->name) }}"/>
                            @error('full_name')<span class="field-error">{{ $message }}</span>@enderror

                            <input type="email" name="email" class="personal-input" placeholder="E-mail"
                                   value="{{ old('email', $address['email'] ?? $lastOrder?->shipping_email ?? auth()->user()?->email) }}"/>
                            @error('email')<span class="field-error">{{ $message }}</span>@enderror

                            <input type="text" name="street" class="personal-input" placeholder="Address"
                                   value="{{ old('street', $address['street'] ?? $lastOrder?->shipping_street ?? auth()->user()?->address) }}"/>
                            @error('street')<span class="field-error">{{ $message }}</span>@enderror

                            <div class="personal-row">
                                <div class="personal-row__item">
                                    <input type="number" name="postal_code" class="personal-input"
                                           placeholder="Post Code"
                                           value="{{ old('postal_code', $address['postal_code'] ?? $lastOrder?->shipping_postal_code ?? auth()->user()?->postcode) }}"/>
                                    @error('postal_code')<span class="field-error">{{ $message }}</span>@enderror
                                </div>

                                <div class="personal-row__item">
                                    <input type="text" name="city" class="personal-input" placeholder="City"
                                           value="{{ old('city', $address['city'] ?? $lastOrder?->shipping_city ?? auth()->user()?->city) }}"/>
                                    @error('city')<span class="field-error">{{ $message }}</span>@enderror
                                </div>
                            </div>

                            <div class="personal-row">
                                @include('partials.country-select', [
                                    'id'       => 'country',
                                    'name'     => 'country',
                                    'required' => true,
                                    'selected' => old('country', $address['country'] ?? $lastOrder?->shipping_country ?? auth()->user()?->country ?? 'SK'),
                                ])
                                @error('country')<span class="field-error">{{ $message }}</span>@enderror

                                <input type="tel" name="phone" class="personal-input"
                                       placeholder="Phone (with state code)"
                                       inputmode="tel" pattern="^\+[0-9]{3}( [0-9]{3}){3}$" maxlength="16"
                                       title="Format: +123 456 789 012"
                                       value="{{ old('phone', $address['phone'] ?? $lastOrder?->shipping_phone) }}"/>
                                @error('phone')<span class="field-error">{{ $message }}</span>@enderror


                            </div>
                            <button type="submit" class="finish-order-btn">
                                Continue to payment
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                     stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M5 12h14M12 5l7 7-7 7"/>
                                </svg>
                            </button>
                        </div>
                    </form>

                </div>

                <div class="order-summary">
                    <h2 class="order-summary__title">Order Summary</h2>

                    <div class="order-summary__rows">
                        <div class="order-summary__row">
                            <span>Subtotal</span>
                            <span>${{ number_format($cartSummary['subtotal_before_discount'] ?? 0, 2) }}</span>
                        </div>
                        <div class="order-summary__row">
                            <span>Discount</span>
                            <span
                                class="order-summary__discount">-${{ number_format($cartSummary['discount_total'] ?? 0, 2) }}</span>
                        </div>
                        <div class="order-summary__row">
                            <span>Delivery Fee</span>
                            <span>${{ number_format($cartSummary['delivery_fee'] ?? 0, 2) }}</span>
                        </div>
                    </div>

                    <div class="order-summary__divider"></div>

                    <div class="order-summary__total">
                        <span>Total</span>
                        <span>${{ number_format($cartSummary['total'] ?? 0, 2) }}</span>
                    </div>
                </div>
            </div>
        </div>
    </main>
@endsection

@push('scripts')
    <script>
        const phoneInput = document.querySelector('input[name="phone"]');

        const formatPhone = (value) => {
            const digits = value.replace(/\D/g, '').slice(0, 12);
            if (!digits.length) {
                return '';
            }

            const groups = [];
            for (let i = 0; i < digits.length; i += 3) {
                groups.push(digits.slice(i, i + 3));
            }

            return `+${groups.join(' ')}`
                .replace(/(\+\d{3})(\d)/, '$1 $2')
                .replace(/(\+\d{3} \d{3})(\d)/, '$1 $2')
                .slice(0, 16);
        };

        const getCaretFromDigits = (formattedValue, digitsBeforeCaret) => {
            if (!digitsBeforeCaret) {
                return 1;
            }

            let digitsSeen = 0;
            for (let i = 0; i < formattedValue.length; i += 1) {
                if (/\d/.test(formattedValue[i])) {
                    digitsSeen += 1;
                }

                if (digitsSeen >= digitsBeforeCaret) {
                    return i + 1;
                }
            }

            return formattedValue.length;
        };

        if (phoneInput) {
            phoneInput.addEventListener('input', (event) => {
                const rawValue = event.target.value;
                const selectionStart = event.target.selectionStart ?? rawValue.length;
                const digitsBeforeCaret = rawValue.slice(0, selectionStart).replace(/\D/g, '').length;

                const formatted = formatPhone(rawValue);
                event.target.value = formatted;

                const nextCaret = getCaretFromDigits(formatted, digitsBeforeCaret);
                event.target.setSelectionRange(nextCaret, nextCaret);
            });

            phoneInput.value = formatPhone(phoneInput.value);
        }
    </script>
@endpush
