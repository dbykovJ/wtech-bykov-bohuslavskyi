<?php $__env->startSection('title', 'Your Cart — SUPERSELL'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/account.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('css/cart.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('css/user-cart.css')); ?>"/>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <main class="cart-main">
        <div class="container">
            <h1 class="cart-title heading">YOUR CART</h1>

            <?php if(session('success')): ?>
                <div class="promo-success-bubble" data-promo-success-bubble>
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(auth()->guard()->check()): ?>
                <?php echo $__env->make('partials.account-nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php else: ?>
                <div class="cart-auth-prompt">
                    <a href="<?php echo e(route('login')); ?>">
                        <p>Please log in to view and manage your account.</p>
                    </a>
                </div>
            <?php endif; ?>

            <div class="cart-layout <?php echo e($cartItems->isEmpty() ? 'cart-layout--empty' : ''); ?>">
                <div class="cart-items">
                    <?php $__empty_1 = true; $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="cart-item">
                            <?php
                                $imageUrl = $item->product->getFirstImage()?->public_url;
                            ?>
                            <?php if($imageUrl): ?>
                                <img src="<?php echo e($imageUrl); ?>" alt="<?php echo e($item->product->name); ?>" class="cart-item__image"/>
                            <?php else: ?>
                                <div class="placeholder cart-item__image"></div>
                            <?php endif; ?>
                            <div class="cart-item__info">
                                <div class="cart-item__top">
                                    <div class="cart-item__name"><?php echo e($item->product->name); ?></div>
                                    <form method="POST" action="/cart/<?php echo e($item->id); ?>">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button class="cart-item__delete" aria-label="Remove item">
                                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                                                 stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                                 stroke-linejoin="round">
                                                <polyline points="3 6 5 6 21 6"/>
                                                <path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/>
                                                <path d="M10 11v6M14 11v6"/>
                                                <path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2"/>
                                            </svg>
                                        </button>
                                    </form>
                                </div>
                                <div class="cart-item__meta">
                                    <span>Size: <strong><?php echo e($item->size->value); ?></strong></span>
                                    <span>Color: <strong><?php echo e($item->color->name); ?></strong></span>
                                </div>
                                <div class="cart-item__bottom">
                                    <div class="cart-item__pricing">
                                        <?php if($item->discount_percent > 0): ?>
                                            <span class="cart-item__price">$<?php echo e(number_format($item->discounted_unit_price, 2)); ?></span>
                                            <span class="cart-item__price" style="text-decoration: line-through; color: #999;">$<?php echo e(number_format($item->base_unit_price, 2)); ?></span>
                                            <span class="badge-red">-<?php echo e(number_format($item->discount_percent)); ?>%</span>
                                        <?php else: ?>
                                            <span class="cart-item__price">$<?php echo e(number_format($item->base_unit_price, 2)); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <form method="POST" action="/cart/<?php echo e($item->id); ?>" class="quantity"
                                          data-count="<?php echo e($item->count); ?>">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                        <input type="hidden" name="count" class="quantity__input"
                                               value="<?php echo e($item->count); ?>">
                                        <button type="button" class="quantity__btn" onclick="changeCount(this, -1)">−
                                        </button>
                                        <span class="quantity__val"><?php echo e($item->count); ?></span>
                                        <button type="button" class="quantity__btn" onclick="changeCount(this, 1)">+
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>Your cart is empty.</p>
                    <?php endif; ?>
                </div>
                <?php if($cartItems->isNotEmpty()): ?>
                    <div class="order-summary">
                        <h2 class="order-summary__title">Order Summary</h2>

                        <div class="order-summary__rows">
                            <div class="order-summary__row">
                                <span>Subtotal</span>
                                <span>$<?php echo e(number_format($cartSummary['subtotal_before_discount'] ?? 0, 2)); ?></span>
                            </div>
                            <div class="order-summary__row">
                                <span>Sale Discount</span>
                                <span
                                    class="order-summary__discount">-$<?php echo e(number_format($cartSummary['sales_discount_total'] ?? 0, 2)); ?></span>
                            </div>
                            <?php if(!empty($cartSummary['promo_code']) && ($cartSummary['promo_discount_total'] ?? 0) >= 0.01): ?>
                                <div class="order-summary__row">
                                    <span>Promo Discount (<?php echo e($cartSummary['promo_code']); ?>)</span>
                                    <span
                                        class="order-summary__discount">-$<?php echo e(number_format($cartSummary['promo_discount_total'] ?? 0, 2)); ?></span>
                                </div>
                            <?php endif; ?>
                            <div class="order-summary__row">
                                <span>Delivery Fee</span>
                                <span>$<?php echo e(number_format($cartSummary['delivery_fee'] ?? 0, 2)); ?></span>
                            </div>
                        </div>

                        <div class="order-summary__divider"></div>

                        <div class="order-summary__total">
                            <span>Total</span>
                            <span>$<?php echo e(number_format($cartSummary['total'] ?? 0, 2)); ?></span>
                        </div>

                        <div class="order-summary__promo">
                            <form method="POST" action="<?php echo e(route('cart.promo.apply')); ?>" class="promo-form">
                                <?php echo csrf_field(); ?>
                                <div class="promo-input-wrap">
                                    <div
                                        class="promo-input <?php echo e($errors->has('promo_code') ? 'promo-input--error' : ''); ?>">
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#aaa"
                                             stroke-width="1.8">
                                            <path
                                                d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/>
                                            <circle cx="7" cy="7" r="1" fill="#aaa" stroke="none"/>
                                        </svg>
                                        <input type="text" name="promo_code" placeholder="Add promo code"
                                               value="<?php echo e(old('promo_code', $cartSummary['promo_code'] ?? '')); ?>"/>
                                    </div>
                                    <?php $__errorArgs = ['promo_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error-bubble" data-promo-error-bubble>
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <button type="submit" class="promo-apply-btn">Apply</button>
                            </form>
                        </div>

                        <?php if(!empty($cartSummary['promo_code'])): ?>
                            <form method="POST" action="<?php echo e(route('cart.promo.remove')); ?>" class="promo-remove-form">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="promo-apply-btn promo-apply-btn--full">Remove Promo
                                    (<?php echo e($cartSummary['promo_code']); ?>)
                                </button>
                            </form>
                        <?php endif; ?>

                        <button class="checkout-btn" onclick="window.location.href='<?php echo e(route('checkout.personal-data')); ?>'">
                            Go to Checkout
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                 stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M5 12h14M12 5l7 7-7 7"/>
                            </svg>
                        </button>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.querySelector('.account-menu-toggle')?.addEventListener('click', function () {
            document.querySelector('.account-nav')?.classList.toggle('account-nav--open');
        });

        function changeCount(btn, delta) {
            const form = btn.closest('form.quantity');
            const input = form.querySelector('.quantity__input');
            const display = form.querySelector('.quantity__val');
            let count = parseInt(input.value) + delta;
            if (count < 1) count = 1;
            input.value = count;
            display.textContent = count;
            form.submit();
        }

        const promoErrorBubble = document.querySelector('[data-promo-error-bubble]');

        if (promoErrorBubble) {
            const hidePromoErrorBubble = () => promoErrorBubble.classList.add('promo-error-bubble--hidden');

            const hideTimer = window.setTimeout(hidePromoErrorBubble, 5000);

            promoErrorBubble.addEventListener('mouseenter', function () {
                window.clearTimeout(hideTimer);
                hidePromoErrorBubble();
            }, {once: true});
        }

        const promoSuccessBubble = document.querySelector('[data-promo-success-bubble]');

        if (promoSuccessBubble) {
            const hideSuccess = () => promoSuccessBubble.classList.add('promo-success-bubble--hidden');
            const successTimer = window.setTimeout(hideSuccess, 4000);

            promoSuccessBubble.addEventListener('mouseenter', function () {
                window.clearTimeout(successTimer);
                hideSuccess();
            }, {once: true});
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/dmytrobykov/Documents/UNI/STU-FIIT/year2/sem2/WTECH/SuperSell/resources/views/account/cart.blade.php ENDPATH**/ ?>