<?php $__env->startSection('title', 'Your Orders — SUPERSELL'); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/account.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('css/user-orders.css')); ?>" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<main class="account-main">
    <div class="container">
        <div class="breadcrumb">
            <a href="<?php echo e(route('home')); ?>">Home</a>
            <span class="breadcrumb__sep">›</span>
            <a href="<?php echo e(route('account')); ?>">My Account</a>
            <span class="breadcrumb__sep">›</span>
            <span class="breadcrumb__current">Orders</span>
        </div>

        <h1 class="account-title heading">MY ORDERS</h1>

        <div class="account-layout">
            <?php echo $__env->make('partials.account-nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <section class="account-content">
                <div class="account-card">
                    <h2 class="account-card__title">Recent orders</h2>
                    <div class="orders-list">
                        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $statusClass = match ($order->status) {
                                    'delivered', 'completed' => 'order-card__status--delivered',
                                    'cancelled' => 'order-card__status--cancelled',
                                    default => 'order-card__status--processing',
                                };
                                $itemsCount = $order->items->sum('quantity');
                                $orderId = str_pad($order->id, 5, '0', STR_PAD_LEFT);
                            ?>
                            <article class="order-card">
                                <div class="order-card__header">
                                    <div>
                                        <div class="order-card__id">Order #<?php echo e($orderId); ?></div>
                                        <div class="order-card__date">Placed on <?php echo e($order->created_at->format('d M Y')); ?></div>
                                    </div>
                                    <div class="order-card__status <?php echo e($statusClass); ?>"><?php echo e(ucfirst(str_replace('_', ' ', $order->status))); ?></div>
                                </div>
                                <div class="order-card__meta">
                                    <div><span>Items:</span> <strong><?php echo e($itemsCount); ?></strong></div>
                                    <div><span>Total:</span> <strong>$<?php echo e(number_format($order->total, 2)); ?></strong></div>
                                    <div><span>Delivery:</span> <strong>$<?php echo e(number_format($order->delivery_fee, 2)); ?></strong></div>
                                </div>
                                <div class="order-card__actions">
                                    <button class="account-btn account-btn--secondary" type="button" data-order-open="<?php echo e($order->id); ?>">
                                        View details
                                    </button>
                                    <form method="POST" action="<?php echo e(route('account.orders.reorder', $order)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button class="account-btn" type="submit">Reorder</button>
                                    </form>
                                </div>
                            </article>

                            <div class="order-modal" id="order-modal-<?php echo e($order->id); ?>" aria-hidden="true">
                                <div class="order-modal__backdrop" data-order-close></div>
                                <div class="order-modal__content" role="dialog" aria-modal="true">
                                    <div class="order-modal__header">
                                        <div>
                                            <div class="order-modal__title">Order #<?php echo e($orderId); ?></div>
                                            <div class="order-modal__subtitle">Placed on <?php echo e($order->created_at->format('d M Y')); ?></div>
                                        </div>
                                        <button type="button" class="order-modal__close" data-order-close>×</button>
                                    </div>
                                    <div class="order-modal__body">
                                        <div class="order-modal__section">
                                            <div class="order-modal__section-title">Items</div>
                                            <div class="order-modal__items">
                                                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="order-modal__item">
                                                        <div style="width: 100%;">
                                                            <div class="order-modal__item-name"><?php echo e($item->product?->name ?? 'Product'); ?></div>
                                                            <div class="order-modal__item-meta">Qty: <?php echo e($item->quantity); ?> · Size: <?php echo e($item->size); ?></div>
                                                            <div class="order-modal__item-price">$<?php echo e(number_format($item->line_total, 2)); ?></div>

                                                            <?php if(Auth::check() && in_array($order->status, ['delivered', 'completed'])): ?>
                                                                <?php if($item->review): ?>
                                                                    <div style="margin-top: 12px; padding: 12px; border-radius: 4px; background-color: #f5f5f5;">
                                                                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                                                                            <span class="star-rating" style="--rating: <?php echo e($item->review->rating); ?>">★★★★★</span>
                                                                            <form method="POST" action="<?php echo e(route('reviews.destroy', $item->review)); ?>" style="display: inline;">
                                                                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                                                <button type="submit" class="account-btn account-btn--secondary" style="padding: 4px 12px; font-size: 12px;">Delete</button>
                                                                            </form>
                                                                        </div>
                                                                        <p style="margin: 0; font-size: 14px; color: #666;"><?php echo e($item->review->body); ?></p>
                                                                        <small style="color: #999;"><?php echo e($item->review->created_at->format('d M Y')); ?></small>
                                                                    </div>
                                                                <?php else: ?>
                                                                    <form method="POST" action="<?php echo e(route('reviews.store')); ?>" style="margin-top: 12px; padding: 12px; border-radius: 4px; background-color: #f5f5f5;">
                                                                        <?php echo csrf_field(); ?>
                                                                        <input type="hidden" name="order_item_id" value="<?php echo e($item->id); ?>">
                                                                        <div style="margin-bottom: 10px;">
                                                                            <label style="display: block; font-size: 12px; margin-bottom: 6px; font-weight: 500;">Rating:</label>
                                                                            <div style="display: flex; gap: 8px;">
                                                                                <?php for($i = 1; $i <= 5; $i++): ?>
                                                                                    <label style="display: flex; align-items: center; gap: 4px; cursor: pointer;">
                                                                                        <input type="radio" name="rating" value="<?php echo e($i); ?>" style="cursor: pointer;">
                                                                                        <span style="font-size: 18px;">★</span>
                                                                                    </label>
                                                                                <?php endfor; ?>
                                                                            </div>
                                                                            <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                <div class="promo-error-bubble"><?php echo e($message); ?></div>
                                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                        </div>
                                                                        <div style="margin-bottom: 10px;">
                                                                            <label style="display: block; font-size: 12px; margin-bottom: 6px; font-weight: 500;">Comment (optional):</label>
                                                                            <textarea name="body" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; font-size: 12px;" rows="2" placeholder="Share your thoughts..."></textarea>
                                                                            <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                <div class="promo-error-bubble"><?php echo e($message); ?></div>
                                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                        </div>
                                                                        <button type="submit" class="account-btn" style="padding: 6px 16px; font-size: 12px;">Submit Review</button>
                                                                    </form>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                        <div class="order-modal__section">
                                            <div class="order-modal__section-title">Summary</div>
                                            <div class="order-modal__summary">
                                                <div><span>Subtotal</span><strong>$<?php echo e(number_format($order->subtotal_before_discount, 2)); ?></strong></div>
                                                <div><span>Discount</span><strong>-$<?php echo e(number_format($order->discount_total, 2)); ?></strong></div>
                                                <div><span>Delivery</span><strong>$<?php echo e(number_format($order->delivery_fee, 2)); ?></strong></div>
                                                <div class="order-modal__summary-total"><span>Total</span><strong>$<?php echo e(number_format($order->total, 2)); ?></strong></div>
                                            </div>
                                        </div>
                                        <div class="order-modal__section">
                                            <div class="order-modal__section-title">Shipping</div>
                                            <div class="order-modal__shipping">
                                                <div><?php echo e($order->shipping_full_name); ?></div>
                                                <div><?php echo e($order->shipping_street); ?></div>
                                                <div><?php echo e($order->shipping_city); ?> <?php echo e($order->shipping_postal_code); ?></div>
                                                <div><?php echo e($order->shipping_country); ?></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p>Your order history is empty.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </section>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.querySelector('.account-menu-toggle').addEventListener('click', function () {
        document.querySelector('.account-nav').classList.toggle('account-nav--open');
    });

    document.querySelectorAll('[data-order-open]').forEach(button => {
        button.addEventListener('click', () => {
            const modal = document.getElementById(`order-modal-${button.dataset.orderOpen}`);
            if (modal) {
                modal.classList.add('order-modal--open');
                modal.setAttribute('aria-hidden', 'false');
            }
        });
    });

    document.querySelectorAll('[data-order_close]').forEach(button => {
        button.addEventListener('click', () => {
            const modal = button.closest('.order-modal');
            if (modal) {
                modal.classList.remove('order-modal--open');
                modal.setAttribute('aria-hidden', 'true');
            }
        });
    });

    document.addEventListener('keydown', e => {
        if (e.key === 'Escape') {
            document.querySelectorAll('.order-modal.order-modal--open').forEach(modal => {
                modal.classList.remove('order-modal--open');
                modal.setAttribute('aria-hidden', 'true');
            });
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/dmytrobykov/Documents/UNI/STU-FIIT/year2/sem2/WTECH/SuperSell/resources/views/account/orders.blade.php ENDPATH**/ ?>