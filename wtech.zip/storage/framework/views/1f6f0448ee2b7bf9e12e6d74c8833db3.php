<?php $__env->startSection('title', 'Your Data — SUPERSELL'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/card.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('css/personal-data.css')); ?>"/>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <main class="personal-main">
        <div class="container">
            <div class="breadcrumb">
                <a href="<?php echo e(route('cart')); ?>">Cart</a>
                <span class="breadcrumb__sep">›</span>
                <span class="breadcrumb__current">Personal data</span>
            </div>

            <h1 class="personal-title heading">YOUR DATA</h1>

            <div class="personal-layout">
                <div class="personal-left">
                    <form class="personal-form" method="POST" action="<?php echo e(route('checkout.personal-data.store')); ?>">

                        <div class="option-card option-card--section">
                            <h2 class="option-card__title">Delivery Method</h2>

                            <label class="option-single-choice">
                                <div class="option-single-choice__left">
                                    <div class="placeholder option-single-choice__logo"></div>
                                    <span class="option-single-choice__name">Truck</span>
                                </div>
                                <input type="radio" name="delivery_method" value="truck" class="option-single-choice__radio"
                                       checked/>
                                <span class="option-single-choice__custom-radio"></span>
                            </label>

                            <label class="option-single-choice">
                                <div class="option-single-choice__left">
                                    <div class="placeholder option-single-choice__logo"></div>
                                    <span class="option-single-choice__name">Post courier</span>
                                </div>
                                <input type="radio" name="delivery_method" value="post" class="option-single-choice__radio"/>
                                <span class="option-single-choice__custom-radio"></span>
                            </label>

                            <label class="option-single-choice">
                                <div class="option-single-choice__left">
                                    <div class="placeholder option-single-choice__logo"></div>
                                    <span class="option-single-choice__name">Drop box near you</span>
                                </div>
                                <input type="radio" name="delivery_method" value="drop box"
                                       class="option-single-choice__radio"/>
                                <span class="option-single-choice__custom-radio"></span>
                            </label>

                            <?php $__errorArgs = ['delivery_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="personal-form-box">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="full_name" class="personal-input" placeholder="Full Name"
                                   value="<?php echo e(old('full_name', $address['full_name'] ?? $lastOrder?->shipping_full_name ?? auth()->user()?->name)); ?>"/>
                            <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <input type="email" name="email" class="personal-input" placeholder="E-mail"
                                   value="<?php echo e(old('email', $address['email'] ?? $lastOrder?->shipping_email ?? auth()->user()?->email)); ?>"/>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <input type="text" name="street" class="personal-input" placeholder="Address"
                                   value="<?php echo e(old('street', $address['street'] ?? $lastOrder?->shipping_street ?? auth()->user()?->address)); ?>"/>
                            <?php $__errorArgs = ['street'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div class="personal-row">
                                <div class="personal-row__item">
                                    <input type="number" name="postal_code" class="personal-input"
                                           placeholder="Post Code"
                                           value="<?php echo e(old('postal_code', $address['postal_code'] ?? $lastOrder?->shipping_postal_code ?? auth()->user()?->postcode)); ?>"/>
                                    <?php $__errorArgs = ['postal_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="personal-row__item">
                                    <input type="text" name="city" class="personal-input" placeholder="City"
                                           value="<?php echo e(old('city', $address['city'] ?? $lastOrder?->shipping_city ?? auth()->user()?->city)); ?>"/>
                                    <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="personal-row">
                                <?php echo $__env->make('partials.country-select', [
                                    'id'       => 'country',
                                    'name'     => 'country',
                                    'required' => true,
                                    'selected' => old('country', $address['country'] ?? $lastOrder?->shipping_country ?? auth()->user()?->country ?? 'SK'),
                                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <input type="tel" name="phone" class="personal-input"
                                       placeholder="Phone (with state code)"
                                       inputmode="tel" pattern="^\+[0-9]{3}( [0-9]{3}){3}$" maxlength="16"
                                       title="Format: +123 456 789 012"
                                       value="<?php echo e(old('phone', $address['phone'] ?? $lastOrder?->shipping_phone)); ?>"/>
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                            </div>
                            <button type="submit" class="finish-order-btn">
                                Continue to payment
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                     stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M5 12h14M12 5l7 7-7 7"/>
                                </svg>
                            </button>
                        </div>
                    </form>

                </div>

                <div class="order-summary">
                    <h2 class="order-summary__title">Order Summary</h2>

                    <div class="order-summary__rows">
                        <div class="order-summary__row">
                            <span>Subtotal</span>
                            <span>$<?php echo e(number_format($cartSummary['subtotal_before_discount'] ?? 0, 2)); ?></span>
                        </div>
                        <div class="order-summary__row">
                            <span>Discount</span>
                            <span
                                class="order-summary__discount">-$<?php echo e(number_format($cartSummary['discount_total'] ?? 0, 2)); ?></span>
                        </div>
                        <div class="order-summary__row">
                            <span>Delivery Fee</span>
                            <span>$<?php echo e(number_format($cartSummary['delivery_fee'] ?? 0, 2)); ?></span>
                        </div>
                    </div>

                    <div class="order-summary__divider"></div>

                    <div class="order-summary__total">
                        <span>Total</span>
                        <span>$<?php echo e(number_format($cartSummary['total'] ?? 0, 2)); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        const phoneInput = document.querySelector('input[name="phone"]');

        const formatPhone = (value) => {
            const digits = value.replace(/\D/g, '').slice(0, 12);
            if (!digits.length) {
                return '';
            }

            const groups = [];
            for (let i = 0; i < digits.length; i += 3) {
                groups.push(digits.slice(i, i + 3));
            }

            return `+${groups.join(' ')}`
                .replace(/(\+\d{3})(\d)/, '$1 $2')
                .replace(/(\+\d{3} \d{3})(\d)/, '$1 $2')
                .slice(0, 16);
        };

        const getCaretFromDigits = (formattedValue, digitsBeforeCaret) => {
            if (!digitsBeforeCaret) {
                return 1;
            }

            let digitsSeen = 0;
            for (let i = 0; i < formattedValue.length; i += 1) {
                if (/\d/.test(formattedValue[i])) {
                    digitsSeen += 1;
                }

                if (digitsSeen >= digitsBeforeCaret) {
                    return i + 1;
                }
            }

            return formattedValue.length;
        };

        if (phoneInput) {
            phoneInput.addEventListener('input', (event) => {
                const rawValue = event.target.value;
                const selectionStart = event.target.selectionStart ?? rawValue.length;
                const digitsBeforeCaret = rawValue.slice(0, selectionStart).replace(/\D/g, '').length;

                const formatted = formatPhone(rawValue);
                event.target.value = formatted;

                const nextCaret = getCaretFromDigits(formatted, digitsBeforeCaret);
                event.target.setSelectionRange(nextCaret, nextCaret);
            });

            phoneInput.value = formatPhone(phoneInput.value);
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/dmytrobykov/Documents/UNI/STU-FIIT/year2/sem2/WTECH/SuperSell/resources/views/personal-data.blade.php ENDPATH**/ ?>