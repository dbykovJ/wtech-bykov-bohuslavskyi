<nav class="navbar">
    <div class="container navbar__inner">
        <a href="<?php echo e(route('home')); ?>" class="navbar__logo heading">SUPERSELL</a>

        <div class="navbar__links">
            <a href="<?php echo e(route('category')); ?>" class="navbar__link">Shop</a>
            <a href="<?php echo e(route('home')); ?>#top-brand-seller" class="navbar__link">Brands</a>
            <a href="<?php echo e(route('home')); ?>#on-sale" class="navbar__link">On Sale</a>
            <a href="<?php echo e(route('home')); ?>#new-arrivals" class="navbar__link">New Arrivals</a>
        </div>

        <div class="navbar__search">
            <form action="<?php echo e(route('category')); ?>" method="GET" class="navbar__search-inner">
                <img draggable="false" src="<?php echo e(asset('assets/icons/search.svg')); ?>" alt="search" />
                <input
                    id="search-input"
                    type="search"
                    name="search"
                    placeholder="Search for Products"
                    value="<?php echo e(request('search')); ?>"
                />
            </form>
        </div>

        <div class="navbar__icons">
            <a href="<?php echo e(route('cart')); ?>">
                <img draggable="false" src="<?php echo e(asset('assets/icons/shopping-cart.svg')); ?>" alt="Cart" />
            </a>
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('account')); ?>">
                    <img draggable="false" class="navbar__user-icon" src="<?php echo e(asset('assets/icons/user.svg')); ?>"
                         alt="Account" />
                </a>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>">
                    <img draggable="false" class="navbar__user-icon" src="<?php echo e(asset('assets/icons/user.svg')); ?>"
                         alt="Account" />
                </a>
            <?php endif; ?>
            <button class="navbar__burger" aria-label="Menu">
                <span></span>
                <span></span>
                <span></span>
            </button>
        </div>
    </div>
</nav>


<?php $__env->startPush('scripts'); ?>
    <script>
        const searchInput = document.getElementById("search-input");

        if (searchInput) {
            let searchTimer;

            searchInput.addEventListener("input", function () {
                clearTimeout(searchTimer);

                const query = this.value.trim();

                // if (query.length < 2) {
                //     return;
                // }

                searchTimer = setTimeout(() => {
                    const baseUrl = "<?php echo e(route('category')); ?>";
                    const url = baseUrl + "?search=" + encodeURIComponent(query);

                    window.location.href = url;
                }, 400);
            });
        }
    </script>
<?php $__env->stopPush(); ?>

<?php /**PATH /Users/dmytrobykov/Documents/UNI/STU-FIIT/year2/sem2/WTECH/SuperSell/resources/views/partials/navbar.blade.php ENDPATH**/ ?>