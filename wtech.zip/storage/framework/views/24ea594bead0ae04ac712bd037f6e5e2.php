<?php $__env->startSection('title', 'Payment — SUPERSELL'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/card.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/payment.css')); ?>" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <main class="payment-main">
        <div class="container">
            <div class="breadcrumb">
                <a href="<?php echo e(route('cart')); ?>">Cart</a>
                <span class="breadcrumb__sep">›</span>
                <a href="<?php echo e(route('checkout.personal-data')); ?>">Personal data</a>
                <span class="breadcrumb__sep">›</span>
                <span class="breadcrumb__current">Payment</span>
            </div>

            <h1 class="payment-title heading">CHECKOUT</h1>

            <?php if($errors->has('checkout')): ?>
                <p class="payment-alert payment-alert--error"><?php echo e($errors->first('checkout')); ?></p>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('payment.pay')); ?>" class="checkout-form">
                <?php echo csrf_field(); ?>

                <div class="payment-layout">
                    <div class="payment-methods">
                        <div class="option-card option-card--section">
                            <h2 class="option-card__title">Payment Method</h2>

                            <label class="option-single-choice">
                                <div class="option-single-choice__left">
                                    <div class="placeholder option-single-choice__logo"></div>
                                    <span class="option-single-choice__name">Card</span>
                                </div>
                                <input type="radio" name="payment_method" value="card" class="option-single-choice__radio" checked />
                                <span class="option-single-choice__custom-radio"></span>
                            </label>

                            <label class="option-single-choice">
                                <div class="option-single-choice__left">
                                    <div class="placeholder option-single-choice__logo"></div>
                                    <span class="option-single-choice__name">Apple Pay</span>
                                </div>
                                <input type="radio" name="payment_method" value="apple_pay" class="option-single-choice__radio" />
                                <span class="option-single-choice__custom-radio"></span>
                            </label>

                            <label class="option-single-choice">
                                <div class="option-single-choice__left">
                                    <div class="placeholder option-single-choice__logo"></div>
                                    <span class="option-single-choice__name">Google Pay</span>
                                </div>
                                <input type="radio" name="payment_method" value="google_pay" class="option-single-choice__radio" />
                                <span class="option-single-choice__custom-radio"></span>
                            </label>

                            <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="option-card option-card--section payment-card-details" data-payment-details="card">
                            <h2 class="option-card__title">Card Details</h2>

                            <div class="checkout-grid">
                                <div class="checkout-field checkout-field--full">
                                    <label for="cardholder_name">Cardholder name</label>
                                    <input id="cardholder_name" name="cardholder_name" type="text" autocomplete="cc-name" placeholder="Jane Doe" />
                                </div>
                                <div class="checkout-field checkout-field--full">
                                    <label for="card_number">Card number</label>
                                    <input id="card_number" name="card_number" type="text" inputmode="numeric" autocomplete="cc-number"
                                           placeholder="1234 5678 9012 3456" pattern="^\d{4}( \d{4}){3}$" maxlength="19" />
                                </div>
                                <div class="checkout-field">
                                    <label for="card_expiry">Expiry</label>
                                    <input id="card_expiry" name="card_expiry" type="text" inputmode="numeric" autocomplete="cc-exp"
                                           placeholder="MM/YY" pattern="^(0[1-9]|1[0-2])\/\d{2}$" maxlength="5" />
                                </div>
                                <div class="checkout-field">
                                    <label for="card_cvc">CVC</label>
                                    <input id="card_cvc" name="card_cvc" type="text" inputmode="numeric" autocomplete="cc-csc"
                                           placeholder="123" pattern="^\d{3,4}$" maxlength="3" />
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="order-summary">
                        <h2 class="order-summary__title">Order Summary</h2>

                        <div class="order-summary__rows">
                            <div class="order-summary__row">
                                <span>Subtotal</span>
                                <span>$<?php echo e(number_format($cartSummary['subtotal_before_discount'] ?? 0, 2)); ?></span>
                            </div>
                            <div class="order-summary__row">
                                <span>Sale Discount</span>
                                <span class="order-summary__discount">-$<?php echo e(number_format($cartSummary['sales_discount_total'] ?? 0, 2)); ?></span>
                            </div>
                            <?php if(!empty($cartSummary['promo_code']) && ($cartSummary['promo_discount_total'] ?? 0) >= 0.01): ?>
                                <div class="order-summary__row">
                                    <span>Promo (<?php echo e($cartSummary['promo_code']); ?>)</span>
                                    <span class="order-summary__discount">-$<?php echo e(number_format($cartSummary['promo_discount_total'], 2)); ?></span>
                                </div>
                            <?php endif; ?>
                            <div class="order-summary__row">
                                <span>Delivery Fee</span>
                                <span>$<?php echo e(number_format($cartSummary['delivery_fee'] ?? 0, 2)); ?></span>
                            </div>
                        </div>

                        <div class="order-summary__divider"></div>

                        <div class="order-summary__total">
                            <span>Total</span>
                            <span>$<?php echo e(number_format($cartSummary['total'] ?? 0, 2)); ?></span>
                        </div>

                        <button type="submit" class="place-order-btn">
                            Pay now
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M5 12h14M12 5l7 7-7 7"/>
                            </svg>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        const paymentRadios = document.querySelectorAll('input[name="payment_method"]');
        const cardDetails = document.querySelector('[data-payment-details="card"]');
        const cardInputs = document.querySelectorAll('#cardholder_name, #card_number, #card_expiry, #card_cvc');
        const cardNumberInput = document.querySelector('#card_number');
        const cardExpiryInput = document.querySelector('#card_expiry');

        const updatePaymentDetails = () => {
            const selected = document.querySelector('input[name="payment_method"]:checked');
            const isCard = selected && selected.value === 'card';

            if (cardDetails) {
                cardDetails.classList.toggle('is-visible', isCard);
                cardDetails.setAttribute('aria-hidden', isCard ? 'false' : 'true');
            }

            cardInputs.forEach((input) => {
                if (input) {
                    input.required = Boolean(isCard);
                }
            });

            paymentRadios.forEach((radio) => {
                const option = radio.closest('.option-single-choice');
                if (option) {
                    option.classList.toggle('payment-option--active', radio.checked);
                }
            });
        };

        paymentRadios.forEach((radio) => {
            radio.addEventListener('change', updatePaymentDetails);
        });

        if (cardNumberInput) {
            cardNumberInput.addEventListener('input', (event) => {
                const digits = event.target.value.replace(/\D/g, '').slice(0, 16);
                const groups = digits.match(/.{1,4}/g) || [];
                event.target.value = groups.join(' ');
            });
        }

        if (cardExpiryInput) {
            cardExpiryInput.addEventListener('input', (event) => {
                const digits = event.target.value.replace(/\D/g, '').slice(0, 4);
                if (digits.length <= 2) {
                    event.target.value = digits;
                    return;
                }
                event.target.value = `${digits.slice(0, 2)}/${digits.slice(2)}`;
            });
        }

        updatePaymentDetails();
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/dmytrobykov/Documents/UNI/STU-FIIT/year2/sem2/WTECH/SuperSell/resources/views/payment.blade.php ENDPATH**/ ?>