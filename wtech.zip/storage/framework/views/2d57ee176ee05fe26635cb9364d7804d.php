<?php if($paginator->hasPages()): ?>
    <nav class="shop-pagination" role="navigation" aria-label="Shop pagination">
        <ul class="shop-pagination__list">
            <?php if($paginator->onFirstPage()): ?>
                <li>
                    <span class="pagination__btn pagination__btn--disabled" aria-disabled="true" aria-label="Previous page">&lsaquo;</span>
                </li>
            <?php else: ?>
                <li>
                    <a class="pagination__btn" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" aria-label="Previous page">&lsaquo;</a>
                </li>
            <?php endif; ?>

            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(is_string($element)): ?>
                    <li><span class="pagination__dots"><?php echo e($element); ?></span></li>
                <?php endif; ?>

                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <li>
                                <span class="pagination__btn active" aria-current="page"><?php echo e($page); ?></span>
                            </li>
                        <?php else: ?>
                            <li>
                                <a class="pagination__btn" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if($paginator->hasMorePages()): ?>
                <li>
                    <a class="pagination__btn" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" aria-label="Next page">&rsaquo;</a>
                </li>
            <?php else: ?>
                <li>
                    <span class="pagination__btn pagination__btn--disabled" aria-disabled="true" aria-label="Next page">&rsaquo;</span>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
<?php endif; ?>

<?php /**PATH /Users/dmytrobykov/Documents/UNI/STU-FIIT/year2/sem2/WTECH/SuperSell/resources/views/vendor/pagination/shop.blade.php ENDPATH**/ ?>