<?php $__env->startSection('title', 'Login — SUPERSELL'); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<main class="auth-main">
    <div class="login-box">
        <h1 class="auth-title">Login</h1>

        <form class="auth-form" method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            <div class="auth-fields">
                <input class="auth-input" id="email" type="email" name="email" placeholder="Username" value="<?php echo e(old('email')); ?>" required autofocus />
                <input class="auth-input" id="password" type="password" name="password" placeholder="Password" required />
            </div>

            <button class="auth-submit" type="submit">Login</button>
        </form>
    </div>

    <div class="auth-footer-text">
        Don't have an account? <a href="<?php echo e(route('register')); ?>">Register.</a>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/dmytrobykov/Documents/UNI/STU-FIIT/year2/sem2/WTECH/SuperSell/resources/views/auth/login.blade.php ENDPATH**/ ?>