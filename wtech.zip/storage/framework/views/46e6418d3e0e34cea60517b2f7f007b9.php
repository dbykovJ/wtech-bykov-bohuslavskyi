<?php $__env->startSection('title', 'My Account — SUPERSELL'); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/account.css')); ?>" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<main class="account-main">
    <div class="container">
        <div class="breadcrumb">
            <a href="<?php echo e(route('home')); ?>">Home</a>
            <span class="breadcrumb__sep">›</span>
            <span class="breadcrumb__current">My Account</span>
        </div>

        <h1 class="account-title heading">MY ACCOUNT</h1>

        <div class="account-layout">
            <?php echo $__env->make('partials.account-nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <section class="account-content">
                <div class="account-card">
                    <h2 class="account-card__title">Profile</h2>
                    <div class="account-profile__header">
                        <div>
                            <div class="account-profile__name"><?php echo e(Auth::user()->name); ?></div>
                            <div class="account-profile__email"><?php echo e(Auth::user()->email); ?></div>
                        </div>
                    </div>
                    <div class="account-profile__meta">
                        <div>
                            <span>Member since:</span>
                            <strong><?php echo e(Auth::user()->created_at->format('M Y')); ?></strong>
                        </div>
                        <div>
                            <span>Total orders</span>
                            <strong>12</strong>
                        </div>
                    </div>
                </div>

                <div class="account-card">
                    <h2 class="account-card__title">Security &amp; preferences</h2>
                    <div class="account-security__list">
                        <div class="account-security__item">
                            <strong>Password:</strong> Last changed 3 months ago
                        </div>
                        <div class="account-security__item">
                            <strong>Email notifications:</strong> Enabled for orders and offers
                        </div>
                    </div>
                    <div class="account-security__actions">
                        <button class="account-btn" type="button" onclick="window.location.href='<?php echo e(route('account.personal-data')); ?>'">
                            Change password
                        </button>
                        <button class="account-btn account-btn--secondary" type="button" onclick="window.location.href='<?php echo e(route('register')); ?>'">
                            Manage email preferences
                        </button>
                    </div>
                </div>
            </section>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.querySelector('.account-menu-toggle').addEventListener('click', function () {
        document.querySelector('.account-nav').classList.toggle('account-nav--open');
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/dmytrobykov/Documents/UNI/STU-FIIT/year2/sem2/WTECH/SuperSell/resources/views/account/index.blade.php ENDPATH**/ ?>