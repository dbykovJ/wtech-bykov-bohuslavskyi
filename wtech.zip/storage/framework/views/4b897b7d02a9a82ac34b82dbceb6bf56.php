<div class="account-menu-toggle">
    <button class="account-menu-toggle__btn" type="button">
        <span class="account-menu-toggle__icon">
            <span></span>
            <span></span>
            <span></span>
        </span>
    </button>
    <span class="account-menu-toggle__label">Account menu</span>
</div>

<aside class="account-nav">
    <div class="account-nav__title">Account menu</div>
    <div class="account-nav__list">
        <a href="<?php echo e(route('account')); ?>"
           class="account-nav__link <?php echo e(request()->routeIs('account') ? 'account-nav__link--active' : ''); ?>">
            Overview
        </a>
        <a href="<?php echo e(route('account.personal-data')); ?>"
           class="account-nav__link <?php echo e(request()->routeIs('account.personal-data') ? 'account-nav__link--active' : ''); ?>">
            Personal data
        </a>
        <a href="<?php echo e(route('account.cart')); ?>"
           class="account-nav__link <?php echo e(request()->routeIs('account.cart') || request()->routeIs('cart') ? 'account-nav__link--active' : ''); ?>">
            Cart &amp; checkout
        </a>
        <a href="<?php echo e(route('account.orders')); ?>"
           class="account-nav__link <?php echo e(request()->routeIs('account.orders') ? 'account-nav__link--active' : ''); ?>">
            Orders
        </a>
        <?php if(auth()->user()?->isAdmin()): ?>
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="account-nav__link">
                Admin Dashboard
            </a>
        <?php endif; ?>
        <?php if(auth()->guard()->check()): ?>
            <form action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="account-nav__link account-nav__link--button">Sign out</button>
            </form>
        <?php endif; ?>
    </div>
</aside>
<?php /**PATH /Users/dmytrobykov/Documents/UNI/STU-FIIT/year2/sem2/WTECH/SuperSell/resources/views/partials/account-nav.blade.php ENDPATH**/ ?>