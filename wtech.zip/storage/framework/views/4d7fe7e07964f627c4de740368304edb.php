<div class="banner">
    Sign up and get 20% off to your first order.
    <a href="<?php echo e(route('register')); ?>">Sign Up Now</a>
    <img
        draggable="false"
        class="banner__close"
        src="<?php echo e(asset('assets/icons/cross.svg')); ?>"
        alt="close"
        onclick="closeElement('banner')"
    />
</div>
<?php /**PATH /Users/dmytrobykov/Documents/UNI/STU-FIIT/year2/sem2/WTECH/SuperSell/resources/views/partials/banner.blade.php ENDPATH**/ ?>