<?php $__env->startSection('title', 'SuperDash — Products'); ?>

<?php $__env->startSection('content'); ?>
    <div class="products-header">
        <h1 class="admin-page-title">Products</h1>
        <a href="<?php echo e(route('admin.products.create')); ?>" class="btn-primary">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                <line x1="12" y1="5" x2="12" y2="19" />
                <line x1="5" y1="12" x2="19" y2="12" />
            </svg>
            Add Product
        </a>
    </div>

    <div class="product-grid">
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="product-card">
                <div class="product-card__image" style="background: none;">
                    <?php
                        $firstImage = $product->getFirstImage();
                        $imagePath = $firstImage?->public_url;
                    ?>
                    <?php if($imagePath): ?>
                        <img
                            style="border-radius: 12px; background: none; object-fit: contain;"
                            src="<?php echo e($imagePath); ?>"
                            alt="<?php echo e($product->name); ?>"
                            class="product-card__img" />
                    <?php endif; ?>
                    
                </div>
                <div class="product-card__body">
                    <div class="product-card__row">
                        <span class="product-card__name"><?php echo e($product->name); ?></span>
                    </div>
                    <p class="product-card__price">$<?php echo e($product->price); ?></p>
                    <p style="color: rgb(118, 97, 97); font-size: 14px; min-height: 40px;"><?php echo e(Str::limit($product->description, 100)); ?></p>
                    <div style="display: flex; gap: 10px;">
                        <a href="<?php echo e(route('admin.products.edit', $product->id)); ?>" class="btn-outline" style="background: dodgerblue; color: white; flex: 2;">Edit Product</a>
                        <form action="<?php echo e(route('admin.products.destroy', $product->id)); ?>" method="POST" class="btn-outline" style="flex: 1;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" style="background: none; border: none;">Delete</button>
                        </form>
                    </div>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="admin-empty">No products yet.</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/dmytrobykov/Documents/UNI/STU-FIIT/year2/sem2/WTECH/SuperSell/resources/views/admin/products.blade.php ENDPATH**/ ?>