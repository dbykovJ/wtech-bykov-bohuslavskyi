<?php $__env->startSection('title', 'SUPERSELL'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <main>
        <section class="hero">
            <div class="container">
                <div class="hero__grid">
                    <div>
                        <h1 class="hero__title">
                            FIND CLOTHES<br />THAT MATCH<br />YOUR STYLE
                        </h1>
                        <p class="hero__desc">
                            Browse through our diverse range of meticulously
                            crafted garments, designed to bring out your
                            individuality and cater to your sense of style.
                        </p>
                        <a href="<?php echo e(route('category')); ?>" class="hero__cta">Shop Now</a>

                        <div class="hero__stats">
                            <div>
                                <div class="hero__stat-num">200+</div>
                                <div class="hero__stat-label">International Brands</div>
                            </div>
                            <div class="hero__stat-divider"></div>
                            <div>
                                <div class="hero__stat-num">2,000+</div>
                                <div class="hero__stat-label">High Quality Products</div>
                            </div>
                            <div class="hero__stat-divider"></div>
                            <div>
                                <div class="hero__stat-num">30,000+</div>
                                <div class="hero__stat-label">Happy Customers</div>
                            </div>
                        </div>
                    </div>

                    <div class="placeholder hero__image"></div>
                </div>
            </div>
        </section>

        <section class="brands-section">
            <div class="container">
                <h2 id="top-brand-seller" class="section-heading">TOP BRAND SELLER</h2>

                <div class="brands-grid">
                    <div class="placeholder brands-grid__main"></div>
                    <div class="brands-grid__center">
                        <div class="placeholder"></div>
                        <div class="placeholder"></div>
                        <div class="placeholder"></div>
                        <div class="placeholder"></div>
                        <div class="placeholder"></div>
                        <div class="placeholder"></div>
                    </div>
                    <div class="brands-grid__right">
                        <div class="placeholder"></div>
                        <div class="placeholder"></div>
                    </div>
                </div>

                <div class="brands-grid--mobile">
                    <div class="placeholder"></div>
                    <div class="placeholder"></div>
                    <div class="placeholder"></div>
                    <div class="placeholder"></div>
                </div>
            </div>
        </section>


        <section class="products-section">
            <div class="container">
                <h2 id="on-sale" class="section-heading">ON SALE</h2>
                <div class="products-grid">
                    <?php $__currentLoopData = $productsOnSale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productOnSale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $imageUrl = $productOnSale->getFirstImage()?->public_url;
                        ?>
                        <a href="<?php echo e(route('product', ['id' => $productOnSale->id])); ?>" class="product-card">
                            <?php if($imageUrl): ?>
                                <img src="<?php echo e($imageUrl); ?>" alt="<?php echo e($productOnSale->name); ?>" class="product-card__image" />
                            <?php else: ?>
                                <div class="placeholder product-card__image"></div>
                            <?php endif; ?>
                            <div class="product-meta">
                                <div class="product-name"><?php echo e($productOnSale->name); ?></div>
                                <div class="star-rating" style="--rating: <?php echo e($productOnSale->rating); ?>">★★★★★</div>
                                <div class="product-price-row">
                                    <span
                                        class="product-price">$<?php echo e(number_format($productOnSale->price - ($productOnSale->price*$productOnSale->total_discount), 2)); ?></span>
                                    <span
                                        class="product-price-original">$<?php echo e(number_format($productOnSale->price, 2)); ?></span>
                                    <span
                                        class="badge-red">-<?php echo e(number_format($productOnSale->total_discount * 100)); ?>%</span>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>

        <section class="products-section products-section--last">
            <div class="container">
                <h2 id="new-arrivals" class="section-heading">NEW ARRIVALS</h2>
                <div class="products-grid">
                    <?php $__currentLoopData = $newArrivals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newArrival): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $imageUrl = $newArrival->getFirstImage()?->public_url;
                        ?>
                        <a href="<?php echo e(route('product', ['id' => $newArrival->id])); ?>" class="product-card">
                            <?php if($imageUrl): ?>
                                <img src="<?php echo e($imageUrl); ?>" alt="<?php echo e($newArrival->name); ?>" class="product-card__image" />
                            <?php else: ?>
                                <div class="placeholder product-card__image"></div>
                            <?php endif; ?>
                            <div class="product-meta">
                                <div class="product-name"><?php echo e($newArrival->name); ?></div>
                                <div class="star-rating" style="--rating: <?php echo e($newArrival->rating); ?>">★★★★★</div>
                                <div class="product-price-row">
                                    <?php if($newArrival->sales->isNotEmpty()): ?>
                                        <?php $total_discount = $newArrival->sales->sum('discount') ?>
                                        <span
                                            class="product-price">$<?php echo e(number_format($newArrival->price - ($newArrival->price*($total_discount/100)), 2)); ?></span>
                                        <span
                                            class="product-price-original">$<?php echo e(number_format($newArrival->price, 2)); ?></span>
                                        <span
                                            class="badge-red">-<?php echo e(number_format($total_discount)); ?>%</span>

                                    <?php else: ?>
                                        <span class="product-price">$<?php echo e(number_format($newArrival->price, 2)); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/dmytrobykov/Documents/UNI/STU-FIIT/year2/sem2/WTECH/SuperSell/resources/views/home.blade.php ENDPATH**/ ?>