<?php $__env->startSection('title', 'Product — SUPERSELL'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/product.css')); ?>" />
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
    <main>

        <div class="container">
            <nav class="breadcrumb">
                <a href="<?php echo e(route('home')); ?>">Home</a>
                <span>›</span>
                <a href="<?php echo e(route('category')); ?>">Shop</a>
                <span>›</span>
                <a href="<?php echo e(route('category')); ?>">T-shirts</a>
                <span>›</span>
                <span class="breadcrumb__current"><?php echo e($product->name); ?></span>
            </nav>

            <section class="product-detail">
                <?php
                    $images = $product->images;
                    $mainImageUrl = $images->first()?->public_url;
                ?>
                <div class="product-gallery">
                    <div class="product-gallery__thumbs" id="product-gallery-thumbs">
                        <?php $__empty_1 = true; $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <img src="<?php echo e($image->public_url); ?>" alt="<?php echo e($product->name); ?>"
                                 data-gallery-image
                                 class="product-gallery__thumb <?php echo e($loop->first ? 'product-gallery__thumb--active' : ''); ?>" />
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="product-gallery__thumb placeholder"></div>
                            <div class="product-gallery__thumb placeholder"></div>
                            <div class="product-gallery__thumb placeholder"></div>
                        <?php endif; ?>
                    </div>
                    <div class="product-gallery__main">
                        <?php if($mainImageUrl): ?>
                            <img src="<?php echo e($mainImageUrl); ?>" alt="<?php echo e($product->name); ?>"
                                 id="product-gallery-main-image"
                                 class="product-gallery-image__main" />
                        <?php else: ?>
                            <div class="product-gallery-image__main placeholder"></div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="product-info">
                    <h1 class="product-info__name heading"><?php echo e($product->name); ?></h1>

                    <div class="product-info__rating">
                        <span class="star-rating" style="--rating: <?php echo e($product->rating); ?>">★★★★★</span>
                        <span class="product-info__rating-count"><?php echo e($product->rating); ?>/5</span>
                    </div>

                    <div class="product-info__price-row">
                        <?php if($product->sales->isNotEmpty()): ?>
                            <?php $total_discount = $product->sales->sum('discount') ?>
                            <span
                                class="product-price">$<?php echo e(number_format($product->price - $product->price * ($total_discount / 100), 2)); ?></span>
                            <span class="product-price-original">$<?php echo e(number_format($product->price, 2)); ?></span>
                            <span class="badge-red">-<?php echo e(number_format($total_discount)); ?>%</span>
                        <?php else: ?>
                            <span class="product-price">$<?php echo e(number_format($product->price, 2)); ?></span>
                        <?php endif; ?>
                    </div>

                    <p class="product-info__desc">
                        <?php echo e($product->description); ?>

                    </p>

                    <div class="product-info__divider"></div>

                    <?php if(isset($product->colorGroups) && $product->colorGroups->isNotEmpty()): ?>
                        <?php
                            $defaultColorId = $product->defaultColorId ?? $product->colorGroups->keys()->first();
                            $defaultGroup =
                                $defaultColorId !== null ? $product->colorGroups[$defaultColorId] ?? null : null;
                            $defaultSizes = $defaultGroup['sizes'] ?? collect();
                            // Do not pre-select any size; customer must choose
                            $defaultSizeCode = null;
                        ?>

                        <div class="product-info__section">
                            <span class="product-info__label">Choose Colors</span>
                            <div class="product-colors" id="product-colors" data-color-sizes='<?php echo json_encode($product->colorGroups, 15, 512) ?>'
                                data-default-color-id="<?php echo e($defaultColorId); ?>">
                                <?php $__currentLoopData = $product->colorGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colorId => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $isActive = $colorId === $defaultColorId;
                                        $hasInStock =
                                            $group['has_in_stock'] ??
                                            collect($group['sizes'])->contains(fn($s) => $s['in_stock'] ?? false);
                                    ?>
                                    <button
                                        class="product-color<?php echo e($isActive ? ' product-color--active' : ''); ?><?php echo e(!$hasInStock ? ' product-color--disabled' : ''); ?>"
                                        style="background: <?php echo e($group['hex_code']); ?>;"
                                        aria-label="<?php echo e($group['name']); ?>" data-color-id="<?php echo e($colorId); ?>"
                                        <?php if(!$hasInStock): ?> disabled aria-disabled="true" <?php endif; ?>></button>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <div class="product-info__divider"></div>

                        <div class="product-info__section">
                            <span class="product-info__label">Choose Size</span>
                            <div class="product-sizes" id="product-sizes">
                                <?php $__empty_1 = true; $__currentLoopData = $defaultSizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php
                                        $isDisabled = !($size['in_stock'] ?? false);
                                        $isActive = !$isDisabled && $size['code'] === $defaultSizeCode;
                                    ?>
                                    <button
                                        class="product-size<?php echo e($isActive ? ' product-size--active' : ''); ?><?php echo e($isDisabled ? ' product-size--disabled' : ''); ?>"
                                        data-size-code="<?php echo e($size['code']); ?>"
                                        <?php if($isDisabled): ?> disabled aria-disabled="true" <?php endif; ?>>
                                        <?php echo e($size['label']); ?>

                                    </button>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <span class="product-sizes__empty">No sizes available for this color.</span>
                                <?php endif; ?>
                            </div>

                            <div id="stock-info" class="product-stock-info">
                                Select a size to see availability
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="product-info__divider"></div>

                    <div class="product-info__actions">
                        <div class="product-qty">
                            <button class="product-qty__btn" onclick="changeQty(-1)">−</button>
                            <span class="product-qty__val" id="qty">1</span>
                            <button class="product-qty__btn" onclick="changeQty(1)">+</button>
                        </div>
                        <form method="POST" action="/cart/add" id="add-to-cart-form">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                            <input type="hidden" name="color_id" id="input-color-id" value="<?php echo e($defaultColorId ?? ''); ?>">
                            <input type="hidden" name="size" id="input-size" value="">
                            <input type="hidden" name="count" id="input-count" value="1">
                            <button type="submit" class="add-to-cart-btn">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/>
                                    <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
                                </svg>
                                Add to Cart
                            </button>
                        </form>

                    </div>
                </div>
            </section>

            <div class="reviews-header">
                <div class="reviews-header__line"></div>
                <span class="reviews-header__title">Rating &amp; Reviews</span>
                <div class="reviews-header__line"></div>
                <div class="reviews-header__nav">
                    <button class="reviews-nav-btn">&#8592;</button>
                    <button class="reviews-nav-btn">&#8594;</button>
                </div>
            </div>

            <section class="reviews">
                <div class="reviews__toolbar">
                    <span class="reviews__count">All Reviews <span class="reviews__count-num">(<?php echo e($product->reviews->count()); ?>)</span></span>
                    <div class="reviews__toolbar-right">
                        <div class="reviews__sort">
                            Latest
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                stroke-width="2">
                                <polyline points="6 9 12 15 18 9" />
                            </svg>
                        </div>
                    </div>
                </div>

                <div class="reviews__grid">
                    <?php $__empty_1 = true; $__currentLoopData = $product->reviews->sortByDesc('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="review-card">
                            <div class="review-card__header">
                                <span class="star-rating" style="--rating: <?php echo e($review->rating); ?>">★★★★★</span>
                                <?php if(Auth::check() && Auth::id() === $review->user_id): ?>
                                    <form method="POST" action="<?php echo e(route('reviews.destroy', $review)); ?>" style="display: inline;">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="review-card__more" onclick="return confirm('Delete this review?')">×</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                            <div class="review-card__author"><?php echo e($review->user->name); ?> <span class="review-card__verified">✔</span></div>
                            <?php if($review->body): ?>
                                <p class="review-card__text">"<?php echo e($review->body); ?>"</p>
                            <?php endif; ?>
                            <span class="review-card__date">Posted on <?php echo e($review->created_at->format('F j, Y')); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php if(Auth::check()): ?>
                            <p style="grid-column: 1/-1; text-align: center; color: #999;">No reviews yet. Be the first to review this product!</p>
                        <?php else: ?>
                            <p style="grid-column: 1/-1; text-align: center; color: #999;">
                                <a href="<?php echo e(route('login')); ?>">Log in</a> to see and write reviews.
                            </p>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>

                <?php if(Auth::check()): ?>
                    <div style="margin-top: 20px; padding: 16px; border-radius: 8px; background-color: #f9f9f9;">
                        <h3 style="margin-top: 0; font-size: 16px;">Write a Review</h3>
                        <p style="margin: 10px 0; font-size: 14px; color: #666;">Have you purchased this product? Share your experience!</p>
                        <a href="<?php echo e(route('account.orders')); ?>" class="account-btn" style="display: inline-block; padding: 10px 20px;">Leave a Review</a>
                    </div>
                <?php else: ?>
                    <div style="margin-top: 20px; padding: 16px; border-radius: 8px; background-color: #f0f0f0;">
                        <p style="margin: 0; font-size: 14px; color: #666;">
                            <a href="<?php echo e(route('login')); ?>" style="color: #333; font-weight: 500;">Log in</a> to write a review based on your purchase.
                        </p>
                    </div>
                <?php endif; ?>
            </section>

            <section class="also-like">
                <h2 class="section-heading">YOU MIGHT ALSO LIKE</h2>
                <div class="also-like__grid">
                    <?php $__currentLoopData = $similar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $imageUrl      = $item->getFirstImage()?->public_url;
                        $activeSales   = $item->sales;
                        $totalDiscount = $activeSales->sum('discount');
                        $salePrice     = $totalDiscount > 0
                            ? $item->price * (1 - $totalDiscount / 100)
                            : null;
                    ?>
                    <a href="<?php echo e(route('product', ['id' => $item->id])); ?>" class="product-card">
                        <?php if($imageUrl): ?>
                            <img src="<?php echo e($imageUrl); ?>" alt="<?php echo e($item->name); ?>" class="product-card__img" />
                        <?php else: ?>
                            <div class="placeholder product-card__img"></div>
                        <?php endif; ?>
                        <div class="product-meta">
                            <div class="product-name"><?php echo e($item->name); ?></div>
                            <div class="star-rating" style="--rating: <?php echo e($item->rating ?? 0); ?>">★★★★★</div>
                            <div class="product-price-row">
                                <?php if($salePrice): ?>
                                    <span class="product-price">$<?php echo e(number_format($salePrice, 2)); ?></span>
                                    <span class="product-price-original">$<?php echo e(number_format($item->price, 2)); ?></span>
                                    <span class="badge-red">-<?php echo e(number_format($totalDiscount)); ?>%</span>
                                <?php else: ?>
                                    <span class="product-price">$<?php echo e(number_format($item->price, 2)); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        let currentMaxQty = Infinity;
        let colorsContainer = document.getElementById('product-colors');
        let sizesContainer = document.getElementById('product-sizes');
        let stockInfoEl = document.getElementById('stock-info');

        let selectedColorBtn = colorsContainer?.querySelector('.product-color--active') ?? null;
        let selectedSizeBtn = sizesContainer?.querySelector('.product-size--active') ?? null;

        function changeQty(delta) {
            const el = document.getElementById("qty");
            let val = parseInt(el.textContent) + delta;
            if (val < 1) val = 1;

            if (Number.isFinite(currentMaxQty) && currentMaxQty > 0 && val > currentMaxQty) {
                val = currentMaxQty;
            }

            el.textContent = val;
            const countInput = document.getElementById('input-count');
            if (countInput) countInput.value = val;
        }

        // Gallery swap — runs immediately since script is at bottom of body
        (function () {
            const galleryThumbs = document.querySelectorAll('[data-gallery-image]');
            const mainGalleryImage = document.getElementById('product-gallery-main-image');

            if (mainGalleryImage && galleryThumbs.length > 0) {
                galleryThumbs.forEach(function (thumb) {
                    thumb.addEventListener('click', function () {
                        galleryThumbs.forEach(function (img) {
                            img.classList.remove('product-gallery__thumb--active');
                        });
                        thumb.classList.add('product-gallery__thumb--active');
                        mainGalleryImage.src = thumb.src;
                        mainGalleryImage.alt = thumb.alt;
                    });
                });
            }
        })();

        document.addEventListener('DOMContentLoaded', function() {
            if (!colorsContainer || !sizesContainer) {
                return;
            }

            const colorSizesRaw = colorsContainer.dataset.colorSizes;
            if (!colorSizesRaw) {
                return;
            }

            let colorSizes;
            try {
                colorSizes = JSON.parse(colorSizesRaw);
            } catch (e) {
                console.error('Failed to parse color sizes data', e);
                return;
            }

            let selectedColorId = colorsContainer.dataset.defaultColorId || null;
            // No default size; user must actively choose one
            let selectedSizeCode = null;

            function getSelectedSize() {
                if (!selectedColorId || !selectedSizeCode) {
                    return null;
                }

                const group = colorSizes[selectedColorId];
                if (!group || !Array.isArray(group.sizes)) {
                    return null;
                }

                return group.sizes.find(function(s) {
                    return s.code === selectedSizeCode;
                }) || null;
            }

            function updateStockInfo() {
                if (!stockInfoEl) {
                    return;
                }

                const size = getSelectedSize();

                if (!size) {
                    stockInfoEl.textContent = 'Select a size to see availability';
                    currentMaxQty = Infinity;
                    return;
                }

                stockInfoEl.textContent = 'In stock: ' + size.count;
                currentMaxQty = size.count;

                const qtyEl = document.getElementById('qty');
                if (qtyEl) {
                    let currentQty = parseInt(qtyEl.textContent) || 1;
                    if (currentQty > currentMaxQty) {
                        qtyEl.textContent = currentMaxQty;
                    }
                }
            }

            function bindSizeButtons() {
                const sizeButtons = sizesContainer.querySelectorAll('.product-size');
                sizeButtons.forEach(function(btn) {
                    if (btn.classList.contains('product-size--disabled')) {
                        return;
                    }

                    btn.addEventListener('click', function() {
                        sizeButtons.forEach(function(b) {
                            b.classList.remove('product-size--active');
                        });

                        btn.classList.add('product-size--active');
                        selectedSizeCode = btn.dataset.sizeCode || null;

                        document.getElementById('input-size').value = selectedSizeCode || '';
                        updateStockInfo();
                    });
                });
            }

            function renderSizesForColor(colorId) {
                const group = colorSizes[colorId];
                if (!group || !Array.isArray(group.sizes) || group.sizes.length === 0) {
                    sizesContainer.innerHTML =
                        '<span class="product-sizes__empty">No sizes available for this color.</span>';
                    return;
                }

                let html = '';

                group.sizes.forEach(function(size) {
                    const isDisabled = !size.in_stock;
                    const isActive = !isDisabled && selectedSizeCode && selectedSizeCode === size.code;

                    html += '<button class="product-size' +
                        (isActive ? ' product-size--active' : '') +
                        (isDisabled ? ' product-size--disabled' : '') +
                        '" data-size-code="' + size.code + '"' +
                        (isDisabled ? ' disabled aria-disabled="true"' : '') +
                        '>' + size.label + '</button>';
                });

                sizesContainer.innerHTML = html;
                bindSizeButtons();
            }

            // Initial binding for server-rendered buttons
            bindSizeButtons();

            const colorButtons = colorsContainer.querySelectorAll('.product-color');
            colorButtons.forEach(function(btn) {
                btn.addEventListener('click', function() {
                    if (btn.disabled || btn.classList.contains('product-color--disabled')) {
                        return;
                    }

                    colorButtons.forEach(function(b) {
                        b.classList.remove('product-color--active');
                    });

                    btn.classList.add('product-color--active');
                    selectedColorId = btn.dataset.colorId;
                    selectedSizeCode = null;

                    document.getElementById('input-color-id').value = selectedColorId || '';
                    document.getElementById('input-size').value = '';
                    renderSizesForColor(selectedColorId);

                    updateStockInfo();
                });
            });

            // Render sizes if we have a default color
            if (selectedColorId && colorSizes[selectedColorId]) {
                renderSizesForColor(selectedColorId);
            }

            updateStockInfo();
        });

        function getSelectedOptions() {
            return {
                color_id: selectedColorBtn ? selectedColorBtn.dataset.colorId : null,
                size: selectedSizeBtn ? selectedSizeBtn.dataset.sizeCode : null,
            };
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/dmytrobykov/Documents/UNI/STU-FIIT/year2/sem2/WTECH/SuperSell/resources/views/product.blade.php ENDPATH**/ ?>