<?php $__env->startSection('title', 'Shop — SUPERSELL'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/category.css')); ?>" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <main class="category-main">
        <div class="container">
            <div class="breadcrumb">
                <a href="<?php echo e(route('home')); ?>">Home</a>
                <span class="breadcrumb__current">Shop</span>
            </div>

            <div class="category-layout">
                <form action="<?php echo e(route('category')); ?>" method="GET" id="filter-form">
                    <aside class="filters">
                        <div class="filters__header">
                            <span class="filters__title">Filters</span>
                            <a href="<?php echo e(route('category')); ?>" class="filters__reset">Reset All</a>
                        </div>

                        <div class="filters__section">
                            <div class="filters__section-title">Categories</div>
                            <div class="filters__categories">
                                <div class="filters__category-item <?php echo e(!request('category') ? 'active' : ''); ?>"
                                     onclick="setCategory('')">
                                    <span>All</span>
                                    <span class="filters__category-radio <?php echo e(!request('category') ? 'filters__category-radio--active' : ''); ?>"></span>
                                </div>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="filters__category-item <?php echo e(request('category') == $cat->id ? 'active' : ''); ?>"
                                         onclick="setCategory('<?php echo e($cat->id); ?>')">
                                        <span><?php echo e($cat->name); ?></span>
                                        <span class="filters__category-radio <?php echo e(request('category') == $cat->id ? 'filters__category-radio--active' : ''); ?>"></span>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <input type="hidden" name="category" id="category-input" value="<?php echo e(request('category')); ?>" />
                            </div>
                        </div>

                        <div class="filters__section">
                            <div class="filters__section-title">Price Range</div>
                            <div class="filters__price-inputs">
                                <div class="filters__price-box">
                                    <span class="filters__price-label">Min</span>
                                    <input type="number" name="min_price" placeholder="$0"
                                           value="<?php echo e(request('min_price')); ?>"
                                           min="0" step="1"
                                           class="filters__price-input" />
                                </div>
                                <span class="filters__price-sep">—</span>
                                <div class="filters__price-box">
                                    <span class="filters__price-label">Max</span>
                                    <input type="number" name="max_price" placeholder="$999"
                                           value="<?php echo e(request('max_price')); ?>"
                                           min="0" step="1"
                                           class="filters__price-input" />
                                </div>
                            </div>
                        </div>

                        <div class="filters__section">
                            <button type="submit" class="filters__apply-btn">Apply Filters</button>
                        </div>
                    </aside>
                </form>

                <div class="products-area">
                    <div class="products-area__header">
                        <div>
                            <h1 class="products-area__title">Shop</h1>
                            <div class="products-area__meta">
                                <?php
                                    $firstItem = $products->firstItem() ?? 0;
                                    $lastItem = $products->lastItem() ?? 0;
                                ?>
                                <?php if(request('search')): ?>
                                    Showing <?php echo e($firstItem); ?>-<?php echo e($lastItem); ?>

                                    of <?php echo e($products->total()); ?> Products for "<?php echo e(request('search')); ?>"
                                <?php else: ?>
                                    Showing <?php echo e($firstItem); ?>-<?php echo e($lastItem); ?>

                                    of <?php echo e($products->total()); ?> Products
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="products-area__sort">
                            Sort by:
                            <div class="select">
                                <div class="select__selected">
                                <span><?php echo e(match(request('sort')) {
                                    'price_asc'  => 'Price: Low to High',
                                    'price_desc' => 'Price: High to Low',
                                    'newest'     => 'Newest',
                                    default      => 'Newest'
                                }); ?></span>
                                    <svg width="10" height="6" viewBox="0 0 10 6" fill="none">
                                        <path d="M1 1l4 4 4-4" stroke="#111" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </div>
                                <ul class="select__dropdown">
                                    <li onclick="setSort('newest')" class="<?php echo e(request('sort', 'newest') === 'newest' ? 'active' : ''); ?>">Newest</li>
                                    <li onclick="setSort('price_asc')" class="<?php echo e(request('sort') === 'price_asc' ? 'active' : ''); ?>">Price: Low to High</li>
                                    <li onclick="setSort('price_desc')" class="<?php echo e(request('sort') === 'price_desc' ? 'active' : ''); ?>">Price: High to Low</li>
                                </ul>
                            </div>
                            <input type="hidden" name="sort" id="sort-input" value="<?php echo e(request('sort')); ?>" form="filter-form" />
                        </div>
                    </div>

                    <div class="category-products-grid">
                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $firstImage = $product->getFirstImage();
                                $imagePath = $firstImage?->public_url;
                            ?>
                            <a href="<?php echo e(route('product', ['id'=>$product->id])); ?>" class="product-card">
                                <?php if($imagePath): ?>
                                    <img src="<?php echo e($imagePath); ?>"
                                         alt="<?php echo e($product->name); ?>"
                                         class="product-card__image" style="object-fit: cover;" />
                                <?php else: ?>
                                    <div class="placeholder product-card__image"></div>
                                <?php endif; ?>
                                <div class="product-meta">
                                    <div class="product-name"><?php echo e($product->name); ?></div>
                                    <?php $discount = $product->sales->sum('discount'); ?>
                                    <div class="product-price-row">
                                        <?php if($discount > 0): ?>
                                            <span class="product-price">$<?php echo e(number_format($product->price - $product->price * ($discount / 100), 2)); ?></span>
                                            <span class="product-price product-price--original" style="text-decoration:line-through; color:#aaa; font-size:0.85em;">$<?php echo e(number_format($product->price, 2)); ?></span>
                                            <span class="badge-red">-<?php echo e(number_format($discount)); ?>%</span>
                                        <?php else: ?>
                                            <span class="product-price">$<?php echo e(number_format($product->price, 2)); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p style="color: #888; font-size: 14px;">No products found.</p>
                        <?php endif; ?>
                    </div>

                    <?php if($products->hasPages()): ?>
                        <div class="pagination">
                            <?php echo e($products->onEachSide(1)->links('vendor.pagination.shop')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/category/select.js')); ?>"></script>
    <script>
        function setCategory(id) {
            document.getElementById('category-input').value = id;
            document.getElementById('filter-form').submit();
        }

        function setSort(value) {
            document.getElementById('sort-input').value = value;
            document.getElementById('filter-form').submit();
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/dmytrobykov/Documents/UNI/STU-FIIT/year2/sem2/WTECH/SuperSell/resources/views/category.blade.php ENDPATH**/ ?>