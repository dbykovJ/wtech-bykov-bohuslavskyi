<?php $__env->startSection('title', 'Order Confirmed — SUPERSELL'); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/order-confirm.css')); ?>" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<main class="confirm-main">
    <div class="container">
        <div class="confirm-box">
            <h1 class="confirm-title heading">THANK YOU FOR SHOPPING AT SUPERSELL</h1>

            <?php if(session('success')): ?>
                <p style="margin: 12px 0; color: #0a7a3f;"><?php echo e(session('success')); ?></p>
            <?php endif; ?>

            <div class="confirm-actions">
                <button class="confirm-btn confirm-btn--full" onclick="window.print()">
                    Print out shopping recipe
                </button>
                <div class="confirm-actions__row">
                    <button class="confirm-btn" onclick="window.location.href='<?php echo e(route('category')); ?>'">
                        Continue shopping
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M5 12h14M12 5l7 7-7 7"/>
                        </svg>
                    </button>
                    <?php if(auth()->guard()->check()): ?>
                        <button class="confirm-btn" onclick="window.location.href='<?php echo e(route('account')); ?>'">
                            To my account
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M5 12h14M12 5l7 7-7 7"/>
                            </svg>
                        </button>
                    <?php else: ?>
                        <button class="confirm-btn" onclick="window.location.href='<?php echo e(route('login')); ?>'">
                            Log in to get the most out of your order
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M5 12h14M12 5l7 7-7 7"/>
                            </svg>
                        </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/dmytrobykov/Documents/UNI/STU-FIIT/year2/sem2/WTECH/SuperSell/resources/views/order-confirm.blade.php ENDPATH**/ ?>