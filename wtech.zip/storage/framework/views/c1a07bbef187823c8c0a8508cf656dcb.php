<?php $__env->startSection('title', 'SuperDash — Orders'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="admin-page-title">Order Lists</h1>

<?php
    $statusBadge = [
        'pending_payment' => 'badge--pending',
        'paid'            => 'badge--paid',
        'processing'      => 'badge--processing',
        'shipped'         => 'badge--in-transit',
        'delivered'       => 'badge--delivered',
        'completed'       => 'badge--completed',
        'cancelled'       => 'badge--cancelled',
    ];
    $dateLabels = [
        'newest'     => 'Newest first',
        'oldest'     => 'Oldest first',
        'this_week'  => 'This week',
        'this_month' => 'This month',
    ];
?>

<form method="GET" action="<?php echo e(route('admin.orders')); ?>" id="filter-form">

    
    <div style="margin-bottom: 16px; display:flex; gap:12px; flex-wrap:wrap; align-items:center;">
        <div style="position:relative; max-width:340px; flex:1 1 240px;">
            <svg style="position:absolute;left:12px;top:50%;transform:translateY(-50%);pointer-events:none;"
                 width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" stroke-width="2">
                <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
            </svg>
            <input
                type="text"
                name="search"
                value="<?php echo e(request('search')); ?>"
                placeholder="Search by name or order ID…"
                style="width:100%;padding:8px 12px 8px 36px;border:1px solid #e5e7eb;border-radius:8px;font-size:14px;outline:none;"
                onchange="document.getElementById('filter-form').submit()">
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <input
                type="number"
                name="min_total"
                value="<?php echo e(request('min_total')); ?>"
                placeholder="Min total"
                min="0"
                step="0.01"
                style="width:120px;padding:8px 10px;border:1px solid #e5e7eb;border-radius:8px;font-size:14px;outline:none;"
                onchange="document.getElementById('filter-form').submit()">
            <input
                type="number"
                name="max_total"
                value="<?php echo e(request('max_total')); ?>"
                placeholder="Max total"
                min="0"
                step="0.01"
                style="width:120px;padding:8px 10px;border:1px solid #e5e7eb;border-radius:8px;font-size:14px;outline:none;"
                onchange="document.getElementById('filter-form').submit()">
        </div>
    </div>

    <div class="order-filters">
        <div class="filter-left">
            <span class="filter-icon">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#6b7280" stroke-width="2">
                    <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>
                </svg>
            </span>
            <span class="filter-by-label">Filter By</span>

            
            <div class="filter-dropdown" id="filter-date">
                <button type="button" class="filter-btn<?php echo e(request('date') ? ' filter-btn--active' : ''); ?>"
                        onclick="toggleDropdown('date-menu')">
                    <span><?php echo e($dateLabels[request('date')] ?? 'Date'); ?></span>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="6 9 12 15 18 9"/>
                    </svg>
                </button>
                <div class="dropdown-menu" id="date-menu">
                    <?php $__currentLoopData = $dateLabels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" onclick="applyFilter('date', '<?php echo e($val); ?>')"><?php echo e($label); ?></button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            
            <?php if($categories->isNotEmpty()): ?>
            <div class="filter-dropdown" id="filter-type">
                <button type="button" class="filter-btn<?php echo e(request('type') ? ' filter-btn--active' : ''); ?>"
                        onclick="toggleDropdown('type-menu')">
                    <span><?php echo e(request('type') ?? 'Order Type'); ?></span>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="6 9 12 15 18 9"/>
                    </svg>
                </button>
                <div class="dropdown-menu" id="type-menu">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" onclick="applyFilter('type', '<?php echo e($cat); ?>')"><?php echo e($cat); ?></button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>

            
            <div class="filter-dropdown" id="filter-status">
                <button type="button" class="filter-btn<?php echo e(request('status') ? ' filter-btn--active' : ''); ?>"
                        onclick="toggleDropdown('status-menu')">
                    <span><?php echo e($statuses[request('status')] ?? 'Order Status'); ?></span>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="6 9 12 15 18 9"/>
                    </svg>
                </button>
                <div class="dropdown-menu" id="status-menu">
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" onclick="applyFilter('status', '<?php echo e($val); ?>')"><?php echo e($label); ?></button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <a href="<?php echo e(route('admin.orders')); ?>" class="reset-filter-btn">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="1 4 1 10 7 10"/>
                <path d="M3.51 15a9 9 0 1 0 .49-3.51"/>
            </svg>
            Reset Filter
        </a>
    </div>

    
    <?php $__currentLoopData = ['date','type','status','min_total','max_total']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(request($f)): ?>
            <input type="hidden" name="<?php echo e($f); ?>" value="<?php echo e(request($f)); ?>">
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</form>

<div class="orders-table-card">
    <table class="admin-table orders-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>NAME</th>
                <th>ADDRESS</th>
                <th>DATE</th>
                <th>TYPE</th>
                <th>PRICE</th>
                <th>STATUS</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $firstItem = $order->items->first();
                $category  = $firstItem?->product?->category?->name ?? '—';
                $address   = implode(', ', array_filter([$order->shipping_city, $order->shipping_country])) ?: '—';
                $name      = $order->shipping_full_name ?? $order->user?->name ?? '—';
                $badge     = $statusBadge[$order->status] ?? 'badge--pending';
                $label     = $statuses[$order->status] ?? ucfirst($order->status);
            ?>
            <tr>
                <td>#<?php echo e(str_pad($order->id, 5, '0', STR_PAD_LEFT)); ?></td>
                <td><?php echo e($name); ?></td>
                <td><?php echo e($address); ?></td>
                <td><?php echo e($order->created_at->format('d M Y')); ?></td>
                <td><?php echo e($category); ?></td>
                <td>$<?php echo e(number_format($order->total, 2)); ?></td>
                <td><span class="badge <?php echo e($badge); ?>"><?php echo e($label); ?></span></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="7" style="text-align:center;color:#9ca3af;padding:32px 0;">No orders found.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <?php if($orders->total()): ?>
    <div class="table-footer">
        <span class="table-showing">
            Showing <?php echo e($orders->firstItem()); ?>–<?php echo e($orders->lastItem()); ?> of <?php echo e($orders->total()); ?>

        </span>
        <div class="pagination">
            <?php if($orders->onFirstPage()): ?>
                <button class="pagination-btn" disabled>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
                </button>
            <?php else: ?>
                <a href="<?php echo e($orders->previousPageUrl()); ?>" class="pagination-btn">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
                </a>
            <?php endif; ?>
            <?php if($orders->hasMorePages()): ?>
                <a href="<?php echo e($orders->nextPageUrl()); ?>" class="pagination-btn">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
                </a>
            <?php else: ?>
                <button class="pagination-btn" disabled>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
                </button>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function toggleDropdown(id) {
        document.querySelectorAll('.dropdown-menu').forEach(m => {
            if (m.id !== id) m.classList.remove('dropdown-menu--open');
        });
        document.getElementById(id).classList.toggle('dropdown-menu--open');
    }

    // Update a hidden input and submit the form
    function applyFilter(name, value) {
        const form = document.getElementById('filter-form');
        let input = form.querySelector(`input[name="${name}"]`);
        if (!input) {
            input = document.createElement('input');
            input.type = 'hidden';
            input.name = name;
            form.appendChild(input);
        }
        input.value = value;
        // Reset page when filter changes
        const pageInput = form.querySelector('input[name="page"]');
        if (pageInput) pageInput.remove();
        form.submit();
    }

    document.addEventListener('click', e => {
        if (!e.target.closest('.filter-dropdown')) {
            document.querySelectorAll('.dropdown-menu').forEach(m => m.classList.remove('dropdown-menu--open'));
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/dmytrobykov/Documents/UNI/STU-FIIT/year2/sem2/WTECH/SuperSell/resources/views/admin/orders.blade.php ENDPATH**/ ?>