<?php use App\Helpers\CountryList; ?>

<select id="<?php echo e($id ?? 'country'); ?>" name="<?php echo e($name ?? 'country'); ?>" <?php echo e($required ?? false ? 'required' : ''); ?>>
    <option value="" disabled <?php echo e(empty($selected) ? 'selected' : ''); ?>>Select a country</option>
    <?php $__currentLoopData = CountryList::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($code); ?>" <?php echo e(($selected ?? '') === $code ? 'selected' : ''); ?>>
            <?php echo e($name); ?>

        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<?php /**PATH /Users/dmytrobykov/Documents/UNI/STU-FIIT/year2/sem2/WTECH/SuperSell/resources/views/partials/country-select.blade.php ENDPATH**/ ?>